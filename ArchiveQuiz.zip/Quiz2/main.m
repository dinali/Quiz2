//
//  main.m
//  Quiz2
//
//  Created by Dina Li on 1/11/13.
//  Copyright (c) 2013 USDA ERS. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ERSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ERSAppDelegate class]));
    }
}
