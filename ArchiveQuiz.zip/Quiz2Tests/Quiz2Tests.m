//
//  Quiz2Tests.m
//  Quiz2Tests
//
//  Created by Dina Li on 1/11/13.
//  Copyright (c) 2013 USDA ERS. All rights reserved.
//

#import "Quiz2Tests.h"

@implementation Quiz2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Quiz2Tests");
}

@end
