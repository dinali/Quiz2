//
//  Quiz2Tests.h
//  Quiz2Tests
//
//  Created by Dina Li on 1/11/13.
//  Copyright (c) 2013 USDA ERS. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Quiz2Tests : SenTestCase

@end
